namespace WinFormsAppMitarbeiterzeit
{
    public partial class Form1 : Form
    {
        Verwaltung verwaltung;
        public Form1()
        {
            InitializeComponent();

            verwaltung = new Verwaltung();

            InitializeUI();
        }

        private void InitializeUI()
        {
            listBoxMitarbeiterzeiten.DataSource = null;
            listBoxMitarbeiterzeiten.DataSource = verwaltung.Mitarbeiterzeiten;
            listBoxMitarbeiterzeiten.DisplayMember = "Mitarbeiter";
            comboBoxProjekte.DataSource = verwaltung.Mitarbeiterzeiten.Select(m => m.Projekt).Distinct().ToList();
            labelAnzahl.Text = verwaltung.MitarbeiterAnzahl.ToString();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonAuswerten_Click(object sender, EventArgs e)
        {
            string selectedProjekt = comboBoxProjekte.SelectedItem.ToString();

            if(selectedProjekt != null)
            {
                double stunden = verwaltung.Mitarbeiterzeiten.Where(m => m.Projekt == selectedProjekt).Sum(m => m.Stunden);
                textBoxAuswerten.Text = stunden.ToString();
            }
        }

        private void buttonDurchschnitt_Click(object sender, EventArgs e)
        {
            string selectedItem = comboBoxProjekte.SelectedItem.ToString();
            if(selectedItem != null)
            {
                double hours = verwaltung.Mitarbeiterzeiten.Where(m => m.Projekt == selectedItem).Average(m => m.Stunden);
                double round = Math.Round(hours, 2);
                textBoxDurchschnitt.Text = round.ToString();
            }
        }

        private void listBoxMitarbeiterzeiten_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
