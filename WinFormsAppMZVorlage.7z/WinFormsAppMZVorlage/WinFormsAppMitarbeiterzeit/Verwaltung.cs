﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAppMitarbeiterzeit
{
    internal class Verwaltung
    {
        public int MitarbeiterAnzahl = 0;
        List<Mitarbeiterzeit> list = new List<Mitarbeiterzeit>();
        List<Verwaltung> verwaltung = new List<Verwaltung>();

        public List<Mitarbeiterzeit> Mitarbeiterzeiten { get => list; set => list = value; }
        
        public Verwaltung()
        {
            einlesen();
        }

        public void einlesen()
        {
            list.Clear();

            string[] zeilen = File.ReadAllLines("Zeiten.csv");

            foreach(string zeile in zeilen)
            {
                string[] teile = zeile.Split(';');

                string mitarbeitername = teile[0];
                DateTime datum = DateTime.Parse(teile[1]);
                double stunden = double.Parse(teile[2]);
                string projekt = teile[3];

                list.Add(new Mitarbeiterzeit(mitarbeitername, datum, stunden, projekt));
                MitarbeiterAnzahl++;
            }
            MitarbeiterAnzahl = list.Count;
        }


    }
}
