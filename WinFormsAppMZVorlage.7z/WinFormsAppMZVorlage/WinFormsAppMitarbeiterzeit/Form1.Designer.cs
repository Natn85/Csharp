﻿namespace WinFormsAppMitarbeiterzeit
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBoxMitarbeiterzeiten = new ListBox();
            comboBoxProjekte = new ComboBox();
            buttonAuswerten = new Button();
            labelAnzahl = new Label();
            textBoxAuswerten = new TextBox();
            textBoxDurchschnitt = new TextBox();
            buttonDurchschnitt = new Button();
            SuspendLayout();
            // 
            // listBoxMitarbeiterzeiten
            // 
            listBoxMitarbeiterzeiten.FormattingEnabled = true;
            listBoxMitarbeiterzeiten.ItemHeight = 15;
            listBoxMitarbeiterzeiten.Location = new Point(36, 33);
            listBoxMitarbeiterzeiten.Margin = new Padding(2, 2, 2, 2);
            listBoxMitarbeiterzeiten.Name = "listBoxMitarbeiterzeiten";
            listBoxMitarbeiterzeiten.Size = new Size(428, 124);
            listBoxMitarbeiterzeiten.TabIndex = 0;
            listBoxMitarbeiterzeiten.SelectedIndexChanged += listBoxMitarbeiterzeiten_SelectedIndexChanged;
            // 
            // comboBoxProjekte
            // 
            comboBoxProjekte.FormattingEnabled = true;
            comboBoxProjekte.Location = new Point(36, 174);
            comboBoxProjekte.Margin = new Padding(2, 2, 2, 2);
            comboBoxProjekte.Name = "comboBoxProjekte";
            comboBoxProjekte.Size = new Size(183, 23);
            comboBoxProjekte.TabIndex = 1;
            // 
            // buttonAuswerten
            // 
            buttonAuswerten.Location = new Point(235, 173);
            buttonAuswerten.Margin = new Padding(2, 2, 2, 2);
            buttonAuswerten.Name = "buttonAuswerten";
            buttonAuswerten.Size = new Size(102, 20);
            buttonAuswerten.TabIndex = 2;
            buttonAuswerten.Text = "Auswerten";
            buttonAuswerten.UseVisualStyleBackColor = true;
            buttonAuswerten.Click += buttonAuswerten_Click;
            // 
            // labelAnzahl
            // 
            labelAnzahl.AutoSize = true;
            labelAnzahl.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelAnzahl.Location = new Point(494, 39);
            labelAnzahl.Margin = new Padding(2, 0, 2, 0);
            labelAnzahl.Name = "labelAnzahl";
            labelAnzahl.Size = new Size(86, 32);
            labelAnzahl.TabIndex = 3;
            labelAnzahl.Text = "Anzahl";
            // 
            // textBoxAuswerten
            // 
            textBoxAuswerten.Location = new Point(360, 177);
            textBoxAuswerten.Margin = new Padding(2, 2, 2, 2);
            textBoxAuswerten.Name = "textBoxAuswerten";
            textBoxAuswerten.Size = new Size(106, 23);
            textBoxAuswerten.TabIndex = 4;
            // 
            // textBoxDurchschnitt
            // 
            textBoxDurchschnitt.Location = new Point(360, 208);
            textBoxDurchschnitt.Margin = new Padding(2, 2, 2, 2);
            textBoxDurchschnitt.Name = "textBoxDurchschnitt";
            textBoxDurchschnitt.Size = new Size(106, 23);
            textBoxDurchschnitt.TabIndex = 6;
            // 
            // buttonDurchschnitt
            // 
            buttonDurchschnitt.Location = new Point(235, 204);
            buttonDurchschnitt.Margin = new Padding(2, 2, 2, 2);
            buttonDurchschnitt.Name = "buttonDurchschnitt";
            buttonDurchschnitt.Size = new Size(102, 20);
            buttonDurchschnitt.TabIndex = 5;
            buttonDurchschnitt.Text = "Durchschnitt";
            buttonDurchschnitt.UseVisualStyleBackColor = true;
            buttonDurchschnitt.Click += buttonDurchschnitt_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(602, 248);
            Controls.Add(textBoxDurchschnitt);
            Controls.Add(buttonDurchschnitt);
            Controls.Add(textBoxAuswerten);
            Controls.Add(labelAnzahl);
            Controls.Add(buttonAuswerten);
            Controls.Add(comboBoxProjekte);
            Controls.Add(listBoxMitarbeiterzeiten);
            Margin = new Padding(2, 2, 2, 2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBoxMitarbeiterzeiten;
        private ComboBox comboBoxProjekte;
        private Button buttonAuswerten;
        private Label labelAnzahl;
        private TextBox textBoxAuswerten;
        private TextBox textBoxDurchschnitt;
        private Button buttonDurchschnitt;
    }
}
