﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAppDVEinfVorlage
{
    public class Mensch
    {
        private string vorname;
        private string nachname;
        private DateTime geburtsdatum;

        public Mensch(string vorname, string nachname, DateTime geburtsdatum)
        {
            Vorname = vorname;
            Nachname = nachname;
            Geburtsdatum = geburtsdatum;
        }
        public string Vorname { get => vorname; set => vorname = value; }
        public string Nachname { get => nachname; set => nachname = value; }
        public DateTime Geburtsdatum { get => geburtsdatum; set => geburtsdatum = value; }
        public override string ToString()
            {
                return vorname + "; " + nachname + "; " + geburtsdatum.ToString();
            }
    }
    
}
