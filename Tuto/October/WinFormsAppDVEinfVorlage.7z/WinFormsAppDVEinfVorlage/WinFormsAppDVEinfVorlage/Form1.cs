namespace WinFormsAppDVEinfVorlage
{
    public partial class Form1 : Form
    {
        Verwaltung verwaltung = new Verwaltung();
        string dateipfad = "menschen.csv";
        public Form1()
        {
            InitializeComponent();
            verwaltung.Laden(dateipfad);
            listAkt();
        }

        private void listBoxMenschen_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonAddCreate_Click(object sender, EventArgs e)
        {
            try
            {
                string vorname = textBoxVorname.Text;
                string nachname = textBoxNachname.Text;
                DateTime geburtsdatum = DateTime.Parse(textBoxGeburtsdatum.Text);

                Mensch m = new Mensch(vorname, nachname, geburtsdatum);
                verwaltung.Hinzuf�gen(m);

                listAkt();
                FelderLeeren();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Fehler beim Erstellen: " + ex.Message);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            verwaltung.Speichern(dateipfad);
            MessageBox.Show("Liste wurde gespeichert!");
        }

        private void listAkt()
        {
            listBoxMenschen.DataSource = null;
            listBoxMenschen.DataSource = verwaltung.menschen;

        }
        
        private void FelderLeeren()
        {
            textBoxVorname.Text = "";
            textBoxNachname.Text = "";
            textBoxGeburtsdatum.Text = "";
        }
    }
}
