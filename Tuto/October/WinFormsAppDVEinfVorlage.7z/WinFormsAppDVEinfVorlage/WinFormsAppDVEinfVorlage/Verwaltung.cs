﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAppDVEinfVorlage
{
    internal class Verwaltung
    {
        public List<Mensch> menschen = new List<Mensch>();
        
        public void Hinzufügen(Mensch m)
        {
            menschen.Add(m);
        }

        public void Speichern(string pfad)
        {
            using(StreamWriter writer = new StreamWriter(pfad))
            {
                foreach (Mensch m in menschen)
                {
                    string zeile = $"{m.Vorname};{m.Nachname};{m.Geburtsdatum:yyyy-MM-dd}";
                    writer.WriteLine(zeile);
                }
            }
        }
        public void Laden(string pfad)
        {
            menschen.Clear();
            if (!File.Exists(pfad)) return;

            string[] zeilen = File.ReadAllLines(pfad);

            foreach (string zeile in zeilen)
            {
                string[] teile = zeile.Split(';');
                if (teile.Length == 3)
                {
                    Mensch m = new Mensch(teile[0], teile[1], DateTime.Parse(teile[2]));
                    menschen.Add(m);
                }
            }
        }
    }
}
