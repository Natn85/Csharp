﻿namespace WinFormsAppDVEinfVorlage
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelVorname = new Label();
            labelNachname = new Label();
            labelGeburtsdatum = new Label();
            textBoxNachname = new TextBox();
            textBoxVorname = new TextBox();
            textBoxGeburtsdatum = new TextBox();
            listBoxMenschen = new ListBox();
            buttonSave = new Button();
            buttonAddCreate = new Button();
            SuspendLayout();
            // 
            // labelVorname
            // 
            labelVorname.AutoSize = true;
            labelVorname.Location = new Point(34, 187);
            labelVorname.Margin = new Padding(2, 0, 2, 0);
            labelVorname.Name = "labelVorname";
            labelVorname.Size = new Size(54, 15);
            labelVorname.TabIndex = 0;
            labelVorname.Text = "Vorname";
            // 
            // labelNachname
            // 
            labelNachname.AutoSize = true;
            labelNachname.Location = new Point(34, 209);
            labelNachname.Margin = new Padding(2, 0, 2, 0);
            labelNachname.Name = "labelNachname";
            labelNachname.Size = new Size(65, 15);
            labelNachname.TabIndex = 1;
            labelNachname.Text = "Nachname";
            // 
            // labelGeburtsdatum
            // 
            labelGeburtsdatum.AutoSize = true;
            labelGeburtsdatum.Location = new Point(34, 232);
            labelGeburtsdatum.Margin = new Padding(2, 0, 2, 0);
            labelGeburtsdatum.Name = "labelGeburtsdatum";
            labelGeburtsdatum.Size = new Size(83, 15);
            labelGeburtsdatum.TabIndex = 2;
            labelGeburtsdatum.Text = "Geburtsdatum";
            // 
            // textBoxNachname
            // 
            textBoxNachname.Location = new Point(144, 206);
            textBoxNachname.Margin = new Padding(2);
            textBoxNachname.Name = "textBoxNachname";
            textBoxNachname.Size = new Size(106, 23);
            textBoxNachname.TabIndex = 3;
            // 
            // textBoxVorname
            // 
            textBoxVorname.Location = new Point(144, 184);
            textBoxVorname.Margin = new Padding(2);
            textBoxVorname.Name = "textBoxVorname";
            textBoxVorname.Size = new Size(106, 23);
            textBoxVorname.TabIndex = 4;
            // 
            // textBoxGeburtsdatum
            // 
            textBoxGeburtsdatum.Location = new Point(144, 228);
            textBoxGeburtsdatum.Margin = new Padding(2);
            textBoxGeburtsdatum.Name = "textBoxGeburtsdatum";
            textBoxGeburtsdatum.Size = new Size(106, 23);
            textBoxGeburtsdatum.TabIndex = 5;
            // 
            // listBoxMenschen
            // 
            listBoxMenschen.FormattingEnabled = true;
            listBoxMenschen.ItemHeight = 15;
            listBoxMenschen.Location = new Point(27, 18);
            listBoxMenschen.Margin = new Padding(2);
            listBoxMenschen.Name = "listBoxMenschen";
            listBoxMenschen.Size = new Size(222, 124);
            listBoxMenschen.TabIndex = 6;
            listBoxMenschen.SelectedIndexChanged += listBoxMenschen_SelectedIndexChanged;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(31, 305);
            buttonSave.Margin = new Padding(2);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(218, 20);
            buttonSave.TabIndex = 7;
            buttonSave.Text = "Speichern";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // buttonAddCreate
            // 
            buttonAddCreate.Location = new Point(31, 281);
            buttonAddCreate.Margin = new Padding(2);
            buttonAddCreate.Name = "buttonAddCreate";
            buttonAddCreate.Size = new Size(218, 20);
            buttonAddCreate.TabIndex = 8;
            buttonAddCreate.Text = "Erstellen und Hinzufügen";
            buttonAddCreate.UseVisualStyleBackColor = true;
            buttonAddCreate.Click += buttonAddCreate_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(272, 352);
            Controls.Add(buttonAddCreate);
            Controls.Add(buttonSave);
            Controls.Add(listBoxMenschen);
            Controls.Add(textBoxGeburtsdatum);
            Controls.Add(textBoxVorname);
            Controls.Add(textBoxNachname);
            Controls.Add(labelGeburtsdatum);
            Controls.Add(labelNachname);
            Controls.Add(labelVorname);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelVorname;
        private Label labelNachname;
        private Label labelGeburtsdatum;
        private TextBox textBoxNachname;
        private TextBox textBoxVorname;
        private TextBox textBoxGeburtsdatum;
        private ListBox listBoxMenschen;
        private Button buttonSave;
        private Button buttonAddCreate;
    }
}
